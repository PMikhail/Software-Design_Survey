public class consoleO extends outPut{
	@Override
	public void displaystring(String a) {
		System.out.println(a);
	}
}
