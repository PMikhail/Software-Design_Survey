public abstract class outPut implements java.io.Serializable{
	public abstract  void displaystring(String a);
}
